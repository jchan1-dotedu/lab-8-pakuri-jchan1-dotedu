from pakuri import *
from pakudex import *
import sys

print("Welcome to Pakudex: Tracker Extraordinaire!")
cap = input("Enter max capacity of the Pakudex: ")
pDex = Pakudex(cap)
print(f"The Pakudex can hold {pDex.get_capacity()} species of Pakuri")
print("\n Pakudex Main Menu")
print("-----------------")
print("1. List Pakuri")
print("2. Show Pakuri")
print("3. Add Pakuri")
print("4. Evolve Pakuri")
print("5. Sort Pakuri")
print("6. Exit")
blah = input("\n What would you like to do? ")
test = int(blah)

match test:
    case 1:
        if pDex.get_size() == 0:
            print("No Pakuri in Pakudex yet!")
        else:
            print("Pakuri In Pakudex:")

            strDex = pDex.get_species_array()

            i = 0
            for species in strDex:
                print(f"{i + 1}. {strDex[i]}")
                i += 1

    case 2:
        spec = input("Enter the name of the species to display: ")
        specList = pDex.get_stats(spec)
        if specList != None:
            print("Error: No such Pakuri!")
        else:
            print("\n Species: " + spec)
            print("\n Attack: " + specList[0])
            print("\n Defense: " + specList[1])
            print("\n Speed: " + specList[2])

    case 3:
        spec = input("Enter the name of the species to add: ")
        
        if len(pDex.get_species_array()) >= pDex.get_capacity():
            print("Error: Pakudex is full!")
        elif spec in pDex.get_species_array():
            print("Error: Pakudex already contains this species!")
        
        else:
            pDex.add_pakuri(spec)

    case 4:
        spec = input("Enter the name of the species to evolve: ")
        
        if spec in pDex.get_species_array():
            pDex.evolve_species(spec)
            print(spec + " has evolved!")
        else:
            print("Error: No such Pakuri!")
            
    case 5:
        pDex.sort_pakuri()
        print("Pakuri have been sorted!")

    case 6:
        print("Thanks for using Pakudex! Bye!")
        sys.exit()
    



